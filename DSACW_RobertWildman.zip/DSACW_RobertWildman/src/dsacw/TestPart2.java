
package dsacw;

/**
 *
 * @author jde
 */
public class TestPart2 {

    TestPart2() {
        // put your constructor code here to initialise any class stuff           
    }
    
    public void run() {
        System.out.println("Part2 started --- Tests for the ENUM and Coin class\n");
        // put your code here to work with the ENUM and Coin class that you built
        System.out.println("You can work with EnumCoin and Coin skeleton code files");
        Coin coin = new Coin();
        System.out.println("\nPart2 completed");
        System.out.println("==============================================\n");
    }
    
    // if you need some class fields you can put them here
}
