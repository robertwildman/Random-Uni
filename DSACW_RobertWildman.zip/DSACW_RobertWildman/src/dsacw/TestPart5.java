
package dsacw;

/**
 *
 * @author jde
 */
public class TestPart5 {
    
    TestPart5() {
        // put your constructor code here to initialise any class fields           
    }
    
    public void run() {
        System.out.println("Part5 started --- Pulling it all together\n");
        // put your code here to pull all the stuff together 
        System.out.println("build your menu and start using all your pre-built code");
        System.out.println("\nPart5 completed");
        System.out.println("==============================================\n");
    }
    
    // you need some class fields so put them here
}
