
package dsacw;

/**
 *
 * @author jde
 */
public class TestPart4 {
    
    TestPart4() {
        // put your constructor code here to initialise any class fields           
    }
    
    public void run() {
        System.out.println("Part4 started --- Tests for the CoinExchanger class\n");
        // put your code here to test the CoinExchanger class that you built
        System.out.println("You can work with CoinExchanger code skeleton");
        CoinExchanger coinExchanger = new CoinExchanger();
        System.out.println("\nPart4 completed");
        System.out.println("==============================================\n");
    }
    
    // you need some class fields so put them here
}
