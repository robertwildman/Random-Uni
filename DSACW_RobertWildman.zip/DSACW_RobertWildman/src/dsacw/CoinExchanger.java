
package dsacw;

/**
 *
 * @author jde
 */
public class CoinExchanger implements IDisplayable {
    
    @Override
    public void displayClassInfo( ) {
        // put your code here
    }

    @Override
    public String getClassInfo( ) {
        // put your code here    
        return "";
    }
    
    CoinExchanger () {
        // put your constructor code here to initialise any class fields etc
    }
        
    // put your class members here for the stacks and queue as well as any operations
    // check your lab solutions for the stacks and queues that you build
}
