
package dsacw;

/**
 *
 * @author jde, 11/03/17
 */
public interface IDisplayable {
    
    public abstract void displayClassInfo( );

    public abstract String getClassInfo( );
 
}
