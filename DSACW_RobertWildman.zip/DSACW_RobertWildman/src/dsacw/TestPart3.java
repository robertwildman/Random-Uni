
package dsacw;

/**
 *
 * @author jde
 */
public class TestPart3 {
    
    TestPart3() {
        // put your constructor code here to initialise any class members etc          
    }
    
    public void run() {
        System.out.println("Part3 started --- Tests for the PiggyBank class\n");
        // put your code here to test the PiggyBank class that you built  
        System.out.println("You can work with PiggyBank code skeleton");
        PiggyBank piggyBank = new PiggyBank();
        System.out.println("\nPart3 completed");
        System.out.println("==============================================\n");
    }
    
    // you might need some class fields so put them here
}
