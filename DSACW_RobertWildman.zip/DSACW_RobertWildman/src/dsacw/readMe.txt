Over and above the files in this zip you will need to provide code for 
STACKS and QUEUES and all parts that you have to write the code for.