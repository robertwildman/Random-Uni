
package dsacw;

/**
 *
 * @author jde
 */
public class Coin implements IDisplayable {
    
    @Override
    public void displayClassInfo( ) {
        // put your code here
    }


    @Override
    public String getClassInfo( ) {
        // put your code here    
        return "";
    }

    Coin() {
        // put your constructor code here to initialise any class fields           
    }    
    
    // you need some getters and setters so put them here
}
