package dsacw;

/**
 *
 * @author jde
 */

public class DsaCW {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        new CourseWork().run();
    }
    
}
