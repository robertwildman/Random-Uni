
package dsacw;

/**
 *
 * @author jde
 */
public class TestPart1 {
    
    TestPart1() {
        // put your constructor code here to initialise any class fields           
    }
    
    public void run() {
        System.out.println("Part1 started\n");
        // put all your code here to work with Part1 class
        Part1 p = new Part1();
        p.displayClassInfo();
        System.out.println(p.getClassInfo());
        System.out.println("You can work with Part1 code skeleton");
        System.out.println("\nPart1 completed");
        System.out.println("==============================================\n");
    }
    
    // you need some class fields so put them here
}
