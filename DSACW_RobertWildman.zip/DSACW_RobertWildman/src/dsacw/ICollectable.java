
package dsacw;

/**
 *
 * @author jde, 28/02/18
 * @param <T>
 */

public interface ICollectable<T> {
    
    public abstract boolean putAway( T t );
    
}
